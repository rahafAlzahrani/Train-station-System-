/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trainproject;

import java.util.ArrayList;

/**
 *
 * @author amoon
 */
public class Booking {
    
    
    boolean isRoundTrip;
    String source;
    String destination;
    String seatClass;
    String departureDate;
    String returnDate;
    int adults;
    String children;
    ArrayList<String> seats = new ArrayList<>();
    String firstName;
    String lastName;
    String nationalId;
    String email;
    String phoneNumber;
    
    
}
