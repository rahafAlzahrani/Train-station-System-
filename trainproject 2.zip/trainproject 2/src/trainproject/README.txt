1.1 If you choose to use( �Railway.Manage), or any of the features of this application, including but not limited to page views, you will be agreeing to abide by all of the terms and conditions of these Terms of Service between you  (�( �Railway.Manage)�), 

1.2 ( �Railway.Manage) may at any time change, add or remove portions of these Terms of Service, which shall become effective immediately upon posting. It is your responsibility to review these Terms of Service prior to each use of the Site and by continuing to use this Site, you agree to any changes.

1.3 if any of these rules or any future changes are unacceptable to you, you may cancel your membership by sending e-mail to:cancel@railwaymanage.com . your continued use of the service now, or following the posting of notice of any changes in these operating rules, will indicate acceptance by you of such rules, changes, or modifications.

1.4 "Railway.Manage" may change, suspend or discontinue any aspect of the Service at any time, including the availability of any Service feature, database, or content. "( Railway.Manage)" may also impose limits on certain features and services or restrict your access to parts or all of the Service without notice or liability.
