
package trainproject;

public class TrainProject {


    public static void main(String[] args) {
        
        new Home().setVisible(true);
        
        
    }
    
}
